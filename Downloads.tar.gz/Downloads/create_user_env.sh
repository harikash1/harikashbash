#!/bin/bash

# Logging configuration
LOG_FILE="/var/log/create_user_env.log"
DATE_TIME=$(date +%Y-%m-%d_%H:%M:%S)

# Function to write log message
log_message() {
  echo "[${DATE_TIME}] - $1" >> "${LOG_FILE}"
}

# Function to check if a file exists
check_file() {
  if [[ ! -f "$1" ]]; then
    log_message "Error: File '$1' does not exist."
    exit 1
  fi
}

# Function to create a user
create_user() {
  username=$(echo "$1" | cut -d ';' -f 1 | cut -d '@' -f 1)
  password=$(echo "$1" | cut -d ';' -f 2 | sed 's/\///g')
  password_hash=$(mkpasswd -m SHA-512 <<< "$password")

  if id "$username" &> /dev/null; then
    log_message "User '$username' already exists, skipping."
  else
    useradd -M -s /bin/bash -p "$password_hash" "$username" &> /dev/null
    log_message "Created user: '$username'"

    # Set password change on first login
    chage -d 0 "$username" &> /dev/null
  fi
}

# Main script body

# Check for input file (command line argument or user prompt)
if [[ $# -eq 0 ]]; then
  read -p "Enter the path to the user data file (local or URI): " file_path
else
  file_path="$1"
fi

check_file "$file_path"

# Download if a URI is provided
if [[ $file_path =~ ^http ]]; then
  wget -qO- "$file_path" > user_data.csv
  file_path="./user_data.csv"
fi

# Parse user data from the file
users=$(tail -n +2 "$file_path" | cut -d ',' -f -1)

# Confirmation prompt
read -p "This script will create $users users. Are you sure? (y/N): " confirmation

if [[ "$confirmation" =~ ^[Yy]$ ]]; then
  # Loop through each user entry
  for user_data in $(cat "$file_path"); do
    log_message "Processing user: '$user_data'"
    create_user "$user_data"

    # Additional user environment configuration (to be added later)
  done
  log_message "User environment configuration completed."
else
  log_message "Script execution cancelled."
fi

