#!/bin/bash

#prompt user for input file location
echo "Enter the input file location(local file system or remote URI);"

# check if input file is a local file system location
if[ -f "$input_file" ]; then
# Input file is a local file system location
file_path=$input_file
else
#Input file is a remote URI
#Download the file to the current directory
wget -q -o input.csv "$input_file"
file_path="input.csv"
fi

